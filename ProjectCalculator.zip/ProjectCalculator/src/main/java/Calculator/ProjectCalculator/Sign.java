package Calculator.ProjectCalculator;

class Sign
{
	char sign;
	
	public Sign(char c)
	{
		sign = c;
	}
	public void setSign(char s)
	{
		sign = s;
	}
	public char getSign()
	{
		return sign;
	}
}
