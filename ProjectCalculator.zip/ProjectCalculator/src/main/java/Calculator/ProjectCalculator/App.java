package Calculator.ProjectCalculator;

import java.util.Scanner;

public class App 
{
    public static void main( String[] args )
    {
    	Scanner sc = new Scanner(System.in);
    	System.out.println("If you want to stop the program type END.");
    	System.out.println("Enter your calculation:");
    	String input = sc.nextLine();
    	
    	while (!(input == "END")) 
    	{
    		if(input == "END")
    		{
    			System.exit(0);
    		}
    		String[] split = input.trim().split("\\s+");

        	Operrand num1 = new Operrand(Double.parseDouble(split[0]));
        	Operrand num2 = new Operrand(Double.parseDouble(split[2]));
        	Sign sign1 = new Sign(split[1].charAt(0));
        	
            Calculator calculator = new Calculator(num1, num2, sign1);
            
            calculator.getResult(split[1].charAt(0));
            System.out.println("Enter your next calculation:");
            
            input = sc.nextLine();
		}
    }
}
