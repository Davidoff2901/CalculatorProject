package Calculator.ProjectCalculator;

import java.text.DecimalFormat;
import java.util.Scanner;

public class App 
{
    public static void main( String[] args )
    {
    	Scanner sc = new Scanner(System.in);
    	double n1 = sc.nextDouble();
    	char sign = sc.next().charAt(0);
    	double n2 = sc.nextDouble();
    	
        Calculator calculator = new App().new Calculator(n1, n2, sign);
        
        switch (sign) {
		case '+':
			calculator.Add();
			break;
		case '-':
			calculator.Subtract();
			break;
		case '*':
			calculator.Multiply();
			break;
		case '/':
			calculator.Divide();
			break;
		default:
			break;
		}
    }
    class Calculator
    {
    	DecimalFormat df = new DecimalFormat("#.###");
    	
    	double number1;
    	double number2;
    	char action;
    	
    	public Calculator(double num1, double num2, char act) 
    	{
    		number1 = num1;
    		number2 = num2;
    		action = act;
    	}
    	public void SetNumber1(double n1)
    	{
    		number1 = n1;
    	}
    	public double GetNumber1()
    	{
    		return number1;
    	}
    	public void SetNumber2(double n2)
    	{
    		number2 = n2;
    	}
    	public double GetNumber2()
    	{
    		return number2;
    	}
    	public void SetAction(char ac)
    	{
    		action = ac;
    	}
    	public char GetAction()
    	{
    		return action;
    	}
    	
    	public void Add()
    	{
    		double result = number1 + number2;
    		System.out.println(df.format(result));
    	}
    	public void Subtract()
    	{
    		double result = number1 - number2;
    		System.out.println(df.format(result));
    	}
    	public void Multiply()
    	{
    		double result = number1 * number2;
    		System.out.println(df.format(result));
    	}
    	public void Divide()
    	{
    		double result = number1 / number2;
    		System.out.println(df.format(result));
    	}
    }

}
