package Calculator.ProjectCalculator;

class Operrand 
{
	double number;
	
	public Operrand(double n)
	{
		number = n;
	}
	public void setNumber(double n)
	{
		number = n;
	}
	public double getNumber()
	{
		return number;
	}
}
