package Calculator.ProjectCalculator;

import java.text.DecimalFormat;

class Add implements CalculatorInterface {
	
	@Override
	public void Calculate(Operrand n1, Operrand n2)
	{
		DecimalFormat df = new DecimalFormat("#.###");
		
		double result = n1.getNumber() + n2.getNumber();
		System.out.println(df.format(result));
	}

}
