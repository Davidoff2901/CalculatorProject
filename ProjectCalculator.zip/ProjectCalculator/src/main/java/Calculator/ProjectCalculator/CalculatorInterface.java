package Calculator.ProjectCalculator;

public interface CalculatorInterface 
{
	void Calculate(Operrand n1, Operrand n2);
}
