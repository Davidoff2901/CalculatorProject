package Calculator.ProjectCalculator;

import java.text.DecimalFormat;

class Calculator
{
	DecimalFormat df = new DecimalFormat("#.###");
	
	Operrand number1;
	Operrand number2;
	Sign action;
	
	public Calculator(Operrand num1, Operrand num2, Sign act) 
	{
		number1 = num1;
		number2 = num2;
		action = act;
	}
	public void SetNumber1(Operrand n1)
	{
		number1 = n1;
	}
	public Operrand GetNumber1()
	{
		return number1;
	}
	public void SetNumber2(Operrand n2)
	{
		number2 = n2;
	}
	public Operrand GetNumber2()
	{
		return number2;
	}
	public void SetAction(Sign ac)
	{
		action = ac;
	}
	public Sign GetAction()
	{
		return action;
	}
	//shape interface call
	public void getResult(char c) 
	{
		CalculatorInterface intface = null;
		switch (c) {
		case '+':
			intface = new Add();
			break;
		case '-':
			intface = new Subtract();
			break;
		case '*':
			intface = new Multiply();
			break;
		case '/':
			intface = new Divide();
			break;
		default:
			break;
		}
		intface.Calculate(number1, number2);
	}
	/*public double Add()
	{
		double result = number1.getNumber() + number2.getNumber();
		System.out.println(df.format(result));
		return result;
		
	}
	public void Subtract()
	{
		double result = number1.getNumber() - number2.getNumber();
		System.out.println(df.format(result));
	}
	public void Multiply()
	{
		double result = number1.getNumber() * number2.getNumber();
		System.out.println(df.format(result));
	}
	public void Divide()
	{
		double result = number1.getNumber() / number2.getNumber();
		System.out.println(df.format(result));
	}*/
}
