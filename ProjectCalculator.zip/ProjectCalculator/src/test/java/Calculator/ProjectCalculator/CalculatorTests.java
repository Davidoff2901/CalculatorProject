package Calculator.ProjectCalculator;

import org.junit.Assert;
import org.junit.Test;


public class CalculatorTests {

	@Test
	public void testAdd() 
	{
		Operrand num1 = new Operrand(1);
		Operrand num2 = new Operrand(2);
		char c = '+';
		
		Calculator test = new Calculator(num1, num2, null);
		
		Assert.assertEquals(3, test.getResult(c), 0f);
	}
	@Test
	public void testAdd_negative() 
	{
		Operrand num1 = new Operrand(-1);
		Operrand num2 = new Operrand(-2);
		
		
		Calculator test = new Calculator(num1, num2, null);
		
		
		Assert.assertEquals(-3, test.Add(), 0f);
	}

}
