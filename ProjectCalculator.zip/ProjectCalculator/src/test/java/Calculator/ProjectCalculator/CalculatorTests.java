package Calculator.ProjectCalculator;

import static org.junit.Assert.*;

import org.junit.Test;

public class CalculatorTests {

	@Test
	public void testAdd() {
		Junit test = new Junit();
	}

}
